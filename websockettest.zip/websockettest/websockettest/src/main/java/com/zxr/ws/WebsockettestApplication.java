package com.zxr.ws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebsockettestApplication {

    public static void main(String[] args) {
        SpringApplication.run(WebsockettestApplication.class, args);
    }

}
